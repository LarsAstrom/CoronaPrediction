import sys
import heapq
import time
import corona

def main(do_plot=False):
    t0 = time.time()
    a_inp,d_inp = corona.read_input()
    alphas,betas,gammas,Ks,Ls = [],[],[],[],[]
    for num_days in range(14,len(a_inp)+1):
        print('Day {} of {} started.'.format(num_days,len(a_inp)))
        a,b,g,k,l = corona.get_best_parameters(a_inp,d_inp,num_days)
        alphas.append(a)
        betas.append(b)
        gammas.append(g)
        Ks.append(k)
        Ls.append(l)
        print('Day {} of {} ended. Time passed: {:.1f}'.format(num_days,len(a_inp),time.time()-t0))

    print('Alpha\t',alphas)
    print('Beta\t',betas)
    print('Gamma\t',gammas)
    print('K\t',Ks)
    print('L\t',Ls)

    if do_plot:
        import matplotlib.pyplot as plt
        plt.figure()
        plt.semilogy(alphas,label='alpha')
        plt.semilogy(betas,label='beta')
        plt.semilogy(gammas,label='gamma')
        plt.semilogy(Ks,label='K')
        plt.semilogy(Ls,label='L')
        plt.legend()
        plt.show()

if __name__ == '__main__':
    do_plot = len(sys.argv) > 1
    main(do_plot)
