import sys
import heapq
import corona

def main(do_plot=False):
    a_inp,d_inp = corona.read_input()
    
    alpha,beta,gamma,K,L = corona.get_best_parameters(a_inp,d_inp)
    s,i,d,r,a = corona.run_simul(alpha,beta,gamma,int(L),K)

    print("\nMean squared error of a is: {:.2f}\n\
Mean squared error of d is: {:.2f}\n\
Penalty function is given by {:.2f}*mse(a)+{:.2f}*mse(d)\n\
The penalty function is {:.2f}\n".format(corona.mse(a_inp,a[:len(a_inp)]),corona.mse(d_inp,d[:len(d_inp)]),corona.a_weight,1-corona.a_weight,corona.score(a_inp,a[:len(a_inp)],d_inp,d[:len(d_inp)])))
    print("Parameters are:\n\
alpha: {}\n\
beta:  {}\n\
gamma: {}\n\
K:     {}\n\
L:     {}".format(alpha,beta,gamma,K,L))

    if do_plot: corona.plot(i,d,s,r,a,a_inp,d_inp)

if __name__ == '__main__':
    do_plot = len(sys.argv) > 1
    main(do_plot)
